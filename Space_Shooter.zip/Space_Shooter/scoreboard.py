from turtle import Turtle

FONT = ("Courier", 24, "normal")


class Scoreboard:
    def __init__(self, type):
        self.score = 1
        self.level = 1
        self.score_board = None
        self.type = type

    def create_board(self):
        board = Turtle()
        board.hideturtle()
        board.color("white")
        board.penup()
        board.color("white")
        if self.type == "score":
            board.goto(-280, 250)
        else:
            board.goto(280, 250)
        self.score_board = board
        self.update_scoreboard()

    def update_scoreboard(self):
        self.score_board.clear()
        if self.type == "score":
            self.score_board.write(f"Score: {self.score}", align="left", font=FONT)
        else:
            self.score_board.write(f"Level: {self.level}", align='right', font=FONT)

    def increase(self):
        if self.type == "score":
            self.score += 1
        else:
            self.level += 1

    def game_over(self):
        self.score_board.goto(0, 0)
        self.score_board.write(f"GAME OVER", align="center", font=FONT)
