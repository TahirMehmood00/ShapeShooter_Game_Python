from turtle import Turtle


class Bullet:
    def __init__(self):
        self.position = None
        self.all_bullets = []

    def create_bullet(self):
        # print("Player ", player)
        new_bullet = Turtle()
        new_bullet.shape("square")
        new_bullet.shapesize(0.3, 1)
        new_bullet.penup()
        new_bullet.color("white")
        new_bullet.goto(self.position)
        new_bullet.left(90)
        self.all_bullets.append(new_bullet)

    def get_position(self, position):
        self.position = position

    def move(self):
        for bul in self.all_bullets:
            bul.forward(10)

