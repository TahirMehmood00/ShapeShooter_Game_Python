from turtle import Turtle
from bullet import Bullet

INITIAL_POSITION = (0, -200)


class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.color("white")
        self.penup()
        self.turtlesize(2)
        self.setheading(90)
        self.goto(INITIAL_POSITION)

    def move_left(self):
        self.left(90)
        self.forward(10)
        self.left(270)

    def move_right(self):
        self.right(90)
        self.forward(10)
        self.right(270)

