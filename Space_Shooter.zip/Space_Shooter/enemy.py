from turtle import Turtle
import random

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class Enemy:
    def __init__(self):
        self.all_enemies = []
        self.speed = STARTING_MOVE_DISTANCE

    def create_enemies(self):
        random_choice = random.randint(1, 6)
        if random_choice == 1:
            random_x = random.randint(-250, 250)
            new_enemy = Turtle("turtle")
            new_enemy.penup()
            new_enemy.color(random.choice(COLORS))
            new_enemy.goto(random_x, 280)
            new_enemy.left(270)
            self.all_enemies.append(new_enemy)

    def move_enemies(self):
        for en in self.all_enemies:
            en.forward(self.speed)

    def level_upgrade(self):
        self.speed += MOVE_INCREMENT
