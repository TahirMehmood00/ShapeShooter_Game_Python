from turtle import Screen
from player import Player
from bullet import Bullet
from enemy import Enemy
from scoreboard import Scoreboard
import time

screen = Screen()
screen.title("Space Shooter")
screen.setup(600, 600)
screen.bgcolor("black")
screen.tracer(0)
score = 10

player = Player()
screen.listen()
bullet = Bullet()
enemy = Enemy()
score_board = Scoreboard("score")
level_board = Scoreboard("level")
score_board.create_board()
level_board.create_board()
screen.listen()
screen.onkey(player.move_left, "Left")
screen.onkey(player.move_right, "Right")
screen.onkey(bullet.create_bullet, "Up")

is_game_on = True
while is_game_on:
    player_pos = (player.xcor(), player.ycor())
    bullet.get_position(player_pos)
    time.sleep(0.1)
    enemy.create_enemies()
    enemy.move_enemies()
    bullet.move()
    screen.update()

    for en in enemy.all_enemies:
        if player.distance(en) < 10:
            print(player.distance(en))
            score_board.game_over()
            is_game_on = False

    for bl in bullet.all_bullets:
        for en in enemy.all_enemies:
            if bl.distance(en) < 15:
                en.hideturtle()
                enemy.all_enemies.remove(en)
                score_board.increase()
                score -= 1
                if score == 0:
                    level_board.increase()
                    enemy.level_upgrade()
                    score = 10
                score_board.update_scoreboard()
                level_board.update_scoreboard()

screen.exitonclick()
